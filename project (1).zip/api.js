/**
 * API Module for SearXNG Image Search
 * Handles fetching images from public SearXNG instances.
 */

const SearXNG_INSTANCES = [
    'https://searx.be',
    'https://priv.au',
    'https://search.disroot.org',
    'https://searx.work',
    'https://searx.tiekoetter.com',
    'https://searx.fmac.xyz',
    'https://searxng.site',
    'https://searx.perennialte.ch',
    'https://searx.gnu.style',
    'https://searx.info',
    'https://searx.nakostech.com',
    'https://searx.name',
    'https://searx.rocks',
    'https://searx.xyz'
];

const CORS_PROXIES = [
    'https://corsproxy.io/?',
    'https://api.allorigins.win/raw?url=',
    'https://thingproxy.freeboard.io/fetch/'
];

const API = {
    /**
     * Fetches image results for a given query.
     * @param {string} query - The search term.
     * @returns {Promise<Array>} - A promise that resolves to an array of image results.
     */
    async searchImages(query) {
        // Try a few instances in parallel to speed up finding a working one
        const BATCH_SIZE = 3;
        for (let i = 0; i < SearXNG_INSTANCES.length; i += BATCH_SIZE) {
            const batch = SearXNG_INSTANCES.slice(i, i + BATCH_SIZE);
            const promises = batch.map(instance => this.fetchFromInstance(instance, query));
            
            try {
                // Use Promise.any to get the first successful response from the batch
                const results = await Promise.any(promises);
                if (results && results.length > 0) return results;
            } catch (error) {
                console.warn(`Batch ${i / BATCH_SIZE + 1} failed:`, error);
                // Continue to next batch
            }
        }

        throw new Error('All search instances and proxies failed. Please check your connection or try again later.');
    },

    async fetchFromInstance(instance, query) {
        for (const proxy of CORS_PROXIES) {
            try {
                const searchUrl = new URL(`${instance}/search`);
                searchUrl.searchParams.append('q', query);
                searchUrl.searchParams.append('format', 'json');
                searchUrl.searchParams.append('categories', 'images');
                searchUrl.searchParams.append('safesearch', '0');

                const proxiedUrl = proxy.includes('allorigins') 
                    ? `${proxy}${encodeURIComponent(searchUrl.toString())}`
                    : `${proxy}${searchUrl.toString()}`;

                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 8000); // 8s timeout per request

                const response = await fetch(proxiedUrl, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json'
                    },
                    signal: controller.signal
                });

                clearTimeout(timeoutId);

                if (!response.ok) throw new Error(`Status ${response.status}`);

                const data = await response.json();

                if (data && data.results && data.results.length > 0) {
                    return data.results.map(result => ({
                        title: result.title || 'Untitled',
                        img_src: result.img_src || result.thumbnail || '',
                        url: result.url || '#',
                        thumbnail: result.thumbnail || result.img_src || '',
                        engine: result.engine || 'unknown'
                    })).filter(img => img.img_src !== '');
                }
            } catch (error) {
                // Continue to next proxy for this instance
            }
        }
        throw new Error(`Failed all proxies for ${instance}`);
    }
};