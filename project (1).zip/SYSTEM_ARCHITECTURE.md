# Universal Image Search System Architecture

## Overview
A client-side web application that allows users to search for images using a public SearXNG instance. The app will focus on a clean, responsive UI and direct API interaction.

## Component Hierarchy
- `index.html`: Main entry point and structural layout.
- `style.css`: Modern styling using CSS Grid/Flexbox and a dark theme.
- `app.js`: Main application logic, event handling, and UI updates.
- `api.js`: Handles API requests to SearXNG instances with error handling and proxy fallbacks.

## State Management
- `query`: Current search term.
- `results`: Array of image objects fetched from the API.
- `loading`: Boolean state for UI feedback.
- `error`: Error message state.

## Data Model (SearXNG Image Result)
```json
{
  "title": "Image Title",
  "img_src": "https://example.com/image.jpg",
  "url": "https://source-page.com",
  "thumbnail": "https://example.com/thumb.jpg",
  "engine": "google/bing/etc"
}
```

## Engineering Standards
- **Client-Side Only**: No backend required; uses public APIs.
- **Responsive Design**: Mobile-first approach.
- **Error Handling**: Graceful handling of API rate limits or blocked instances.