# Implementation TODO

- [x] Research CORS-friendly APIs
- [x] Create SYSTEM_ARCHITECTURE.md
- [x] Create TODO.md
- [x] Create index.html (Enhanced with bulk controls)
- [x] Create style.css (Updated with progress bar and bulk styles)
- [x] Create api.js (Parallelized search and more instances)
- [x] Create app.js (Bulk download and individual download logic)
- [x] Test with multiple search queries
- [x] Final Review