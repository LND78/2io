/**
 * App Module for UI Logic and Event Handling.
 */

const App = {
    init() {
        this.searchInput = document.getElementById('search-input');
        this.searchButton = document.getElementById('search-button');
        this.imageGrid = document.getElementById('image-grid');
        this.statusMessage = document.getElementById('status-message');
        this.loader = document.getElementById('loader');
        this.bulkControls = document.getElementById('bulk-controls');
        this.bulkCountInput = document.getElementById('bulk-count');
        this.bulkDownloadBtn = document.getElementById('bulk-download-btn');
        this.progressBar = document.getElementById('progress-bar');
        this.progressContainer = document.getElementById('progress-container');

        this.currentResults = [];
        this.bindEvents();
    },

    bindEvents() {
        this.searchButton.addEventListener('click', () => this.handleSearch());
        this.searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.handleSearch();
            }
        });
        this.bulkDownloadBtn.addEventListener('click', () => this.handleBulkDownload());
    },

    async handleSearch() {
        const query = this.searchInput.value.trim();
        if (!query) return;

        this.clearResults();
        this.showLoader(true);
        this.bulkControls.classList.add('hidden');
        this.updateStatus('Searching across multiple instances...');

        try {
            const results = await API.searchImages(query);
            this.currentResults = results;
            if (results.length === 0) {
                this.updateStatus('No images found for your query. Please try a different search term.', true);
            } else {
                this.updateStatus(`Found ${results.length} images.`);
                this.renderImages(results);
                this.bulkControls.classList.remove('hidden');
            }
        } catch (error) {
            console.error('Search failed:', error);
            this.updateStatus(`Search failed after multiple attempts. ${error.message}`, true);
        } finally {
            this.showLoader(false);
        }
    },

    renderImages(images) {
        this.imageGrid.innerHTML = '';
        images.forEach((image, index) => {
            const card = document.createElement('div');
            card.className = 'image-card';

            const img = document.createElement('img');
            img.src = image.thumbnail || image.img_src;
            img.alt = image.title;
            img.loading = 'lazy';

            const info = document.createElement('div');
            info.className = 'info';
            info.textContent = image.title;

            const link = document.createElement('a');
            link.href = image.url;
            link.target = '_blank';
            link.rel = 'noopener noreferrer';

            const downloadBtn = document.createElement('button');
            downloadBtn.className = 'download-btn';
            downloadBtn.textContent = 'Download';
            downloadBtn.onclick = (e) => {
                e.stopPropagation();
                this.downloadImage(image.img_src, `image-${index}.jpg`);
            };

            card.appendChild(img);
            card.appendChild(info);
            card.appendChild(link);
            card.appendChild(downloadBtn);
            this.imageGrid.appendChild(card);
        });
    },

    async downloadImage(url, filename) {
        try {
            const response = await fetch(`https://corsproxy.io/?${encodeURIComponent(url)}`);
            const blob = await response.blob();
            const downloadUrl = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = downloadUrl;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(downloadUrl);
        } catch (error) {
            console.error('Download failed:', error);
            alert('Could not download image. Try opening the image in a new tab.');
        }
    },

    async handleBulkDownload() {
        const count = parseInt(this.bulkCountInput.value);
        const imagesToDownload = this.currentResults.slice(0, count);
        
        if (imagesToDownload.length === 0) return;

        this.bulkDownloadBtn.disabled = true;
        this.progressContainer.classList.remove('hidden');
        this.updateProgressBar(0);

        const zip = new JSZip();
        const folder = zip.folder("images");

        for (let i = 0; i < imagesToDownload.length; i++) {
            const img = imagesToDownload[i];
            try {
                const response = await fetch(`https://corsproxy.io/?${encodeURIComponent(img.img_src)}`);
                const blob = await response.blob();
                folder.file(`image-${i}.jpg`, blob);
            } catch (error) {
                console.warn(`Failed to add image ${i} to zip:`, error.message);
            }
            this.updateProgressBar(((i + 1) / imagesToDownload.length) * 100);
        }

        const content = await zip.generateAsync({ type: "blob" });
        const downloadUrl = window.URL.createObjectURL(content);
        const link = document.createElement('a');
        link.href = downloadUrl;
        link.download = "search_results.zip";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(downloadUrl);

        this.bulkDownloadBtn.disabled = false;
        this.progressContainer.classList.add('hidden');
    },

    updateProgressBar(percent) {
        this.progressBar.style.width = `${percent}%`;
    },

    clearResults() {
        this.imageGrid.innerHTML = '';
    },

    updateStatus(message, isError = false) {
        this.statusMessage.textContent = message;
        if (isError) {
            this.statusMessage.classList.add('error-status');
        } else {
            this.statusMessage.classList.remove('error-status');
        }
    },

    showLoader(show) {
        if (show) {
            this.loader.classList.remove('hidden');
        } else {
            this.loader.classList.add('hidden');
        }
    }
};

// Initialize the app
document.addEventListener('DOMContentLoaded', () => App.init());